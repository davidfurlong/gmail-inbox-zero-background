# Limitations

Does not support "multiple inbox" mode