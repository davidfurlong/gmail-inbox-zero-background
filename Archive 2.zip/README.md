
# Gmail inbox zero background
Makes your inbox zero pretty with a new beautiful image from unsplash every day

## Install
- [Google Chrome Extension](https://chrome.google.com/webstore/detail/gmail-inbox-zero-backgrou/fadepmbdhojcogdjcihbhdcbfpacdbdg)
- [Firefox Extension](https://addons.mozilla.org/en-GB/firefox/addon/gmail-inbox-zero-background/)

![alt text](https://lh3.googleusercontent.com/JehvqxajT9dMSoRoKQ0RNxFtMPIvuVBXqWr_g5ODViMlb7Vb0IQ6KNz0Xb4rQQ34JoWN4aZx7Q=w640-h400-e365)

# Limitations
Does not support "multiple inbox" mode